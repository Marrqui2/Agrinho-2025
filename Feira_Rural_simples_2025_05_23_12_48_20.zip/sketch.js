let carrinho;
let produtos = [];
let coletados = [];
let gameState = "compra";
let selecionado = null;
let precos = [];
let totalCompra = 0;
let caixa;
let pagamentoRealizado = false;
let saldoDisponivel;
let cartaoAnimado = null;
let maquininha;
let carrinhoMovendo = false;
let destinoCarrinhoX = 0;
let destinoCarrinhoY = 0;

let emojis = ["🍎", "🍇", "🍓", "🍉", "🥕", "🍍", "🍅", "🥬", "🌽", "🥑", "🍒", "🍑", "🥝", "🍋", "🍊"];

function preload() {
  // Imagem da maquininha de cartão (substitua pelo seu caminho de imagem)
  // maquininha = loadImage('maquininha.png');
}

function setup() {
  createCanvas(900, 550);
  textAlign(CENTER, CENTER);
  textSize(32);

  // Define saldo aleatório
  saldoDisponivel = random(20, 101).toFixed(2); // Entre R$20 e R$100
  
  carrinho = new Carrinho();
  caixa = new CaixaEletronico();

  // Criar produtos nas prateleiras com preços aleatórios
  let xStart = 100;
  let yStart = 80;
  let espaco = 80;
  let produtosPorPrateleira = 5;

  for (let prateleira = 0; prateleira < 3; prateleira++) {
    for (let i = 0; i < produtosPorPrateleira; i++) {
      let x = xStart + (i % produtosPorPrateleira) * espaco;
      let y = yStart + prateleira * 80;
      let preco = random(1, 10).toFixed(2);
      let emojiAleatorio = emojis[floor(random(emojis.length))];
      produtos.push(new Produto(x, y, emojiAleatorio, preco));
      precos.push(preco);
    }
  }
}

function draw() {
  background(240, 240, 200);

  drawPrateleiras();

  for (let p of produtos) {
    p.show();
    if (!p.pego) {
      p.showPreco();
    }
  }

  // Atualiza posição do carrinho se estiver se movendo
  if (carrinhoMovendo) {
    moverCarrinhoParaCaixa();
  }
  
  carrinho.show();
  caixa.show();

  // Mostra informações da compra
  fill(50);
  textSize(16);
  text(`Produtos: ${coletados.length}`, 200, 30);
  text(`Total: R$ ${totalCompra.toFixed(2)}`, 400, 30);
  text(`Saldo: R$ ${saldoDisponivel}`, 600, 30);

  // Verifica se excedeu o saldo
  if (totalCompra > parseFloat(saldoDisponivel)) {
    fill(255, 0, 0);
    text("Saldo insuficiente!", width/2, height - 20);
  }

  if (gameState === "pagamento") {
    drawTelaPagamento();
  } else if (gameState === "fim") {
    drawTelaFinal();
  }
  
  // Animação do cartão passando na maquininha
  if (cartaoAnimado) {
    cartaoAnimado.update();
    cartaoAnimado.show();
    
    if (cartaoAnimado.finished) {
      cartaoAnimado = null;
      if (gameState === "processando") {
        gameState = "fim";
      }
    }
  }
}

function moverCarrinhoParaCaixa() {
  // Calcula a direção para o caixa
  let dx = destinoCarrinhoX - carrinho.x;
  let dy = destinoCarrinhoY - carrinho.y;
  let distancia = sqrt(dx * dx + dy * dy);
  
  // Velocidade de movimento
  let velocidade = 3;
  
  if (distancia > 5) {
    // Normaliza a direção e move
    dx /= distancia;
    dy /= distancia;
    carrinho.x += dx * velocidade;
    carrinho.y += dy * velocidade;
  } else {
    // Chegou ao destino
    carrinhoMovendo = false;
    gameState = "pagamento";
  }
}

function drawTelaPagamento() {
  // Fundo da tela de pagamento
  fill(200, 220, 240);
  rect(200, 100, 500, 350, 20);
  
  // Textos do caixa
  fill(0);
  textSize(24);
  text("CAIXA ELETRÔNICO", width/2, 130);
  textSize(20);
  text(`Total: R$ ${totalCompra.toFixed(2)}`, width/2, 180);
  text(`Saldo: R$ ${saldoDisponivel}`, width/2, 210);
  
  // Botões de pagamento com ícones
  fill(100, 200, 100);
  rect(width/2 - 100, 250, 200, 50, 10);
  fill(70, 150, 220);
  rect(width/2 - 100, 310, 200, 50, 10);
  fill(220, 180, 70);
  rect(width/2 - 100, 370, 200, 50, 10);
  
  fill(255);
  textSize(18);
  text("💳 DÉBITO", width/2, 275);
  text("💳 CRÉDITO", width/2, 335);
  text("💵 DINHEIRO", width/2, 395);
  
  // Botão de cancelar
  fill(200, 100, 100);
  rect(width/2 - 100, 430, 200, 50, 10);
  fill(255);
  text("❌ CANCELAR", width/2, 455);
}

function drawTelaFinal() {
  background(240, 240, 200);
  fill(20, 120, 20);
  textSize(24);
  text("🛒 Obrigado pela compra!", width / 2, 60);
  textSize(32);
  text(coletados.join(" "), width / 2, height / 2 - 30);
  textSize(20);
  text(`Total: R$ ${totalCompra.toFixed(2)}`, width / 2, height / 2 + 20);
  text(`Saldo restante: R$ ${(saldoDisponivel - totalCompra).toFixed(2)}`, width / 2, height / 2 + 60);
  textSize(16);
  fill(100);
  text("Pressione ESPAÇO para reiniciar", width / 2, height - 30);
}

function drawPrateleiras() {
  fill(180, 140, 90);
  for (let i = 0; i < 3; i++) {
    rect(80, 60 + i * 80, 360, 20);
  }
}

function mousePressed() {
  if (gameState === "compra") {
    for (let p of produtos) {
      if (!p.pego && p.isMouseOver()) {
        selecionado = p;
        break;
      }
    }
    
    // Verifica se clicou no carrinho para pagar
    if (dist(mouseX, mouseY, carrinho.x, carrinho.y) < 30 && coletados.length > 0) {
      // Define o destino do carrinho (posição em frente ao caixa)
      destinoCarrinhoX = caixa.x - 100;
      destinoCarrinhoY = caixa.y + 80;
      carrinhoMovendo = true;
    }
  } 
  else if (gameState === "pagamento") {
    if (mouseX > width/2 - 100 && mouseX < width/2 + 100) {
      if (mouseY > 250 && mouseY < 300) { // Débito
        iniciarAnimacaoCartao("Débito");
      } 
      else if (mouseY > 310 && mouseY < 360) { // Crédito
        iniciarAnimacaoCartao("Crédito");
      }
      else if (mouseY > 370 && mouseY < 420) { // Dinheiro
        processarPagamento("Dinheiro");
      }
      else if (mouseY > 430 && mouseY < 480) { // Cancelar
        // Volta o carrinho para a posição original
        destinoCarrinhoX = 700;
        destinoCarrinhoY = height - 60;
        carrinhoMovendo = true;
        gameState = "compra";
      }
    }
  }
}

function iniciarAnimacaoCartao(metodo) {
  if (totalCompra <= parseFloat(saldoDisponivel)) {
    gameState = "processando";
    cartaoAnimado = new CartaoAnimado(metodo);
  } else {
    alert("Saldo insuficiente para esta compra!");
  }
}

function processarPagamento(metodo) {
  if (totalCompra <= parseFloat(saldoDisponivel)) {
    saldoDisponivel = (parseFloat(saldoDisponivel) - totalCompra).toFixed(2);
    gameState = "fim";
    
    if (metodo === "Dinheiro") {
      for (let i = 0; i < 10; i++) {
        setTimeout(() => {
          fill(220, 180, 70);
          textSize(20);
          text("💵", random(width/2 - 50, width/2 + 50), random(height/2 - 100, height/2 + 100));
        }, i * 100);
      }
    }
  } else {
    alert("Saldo insuficiente para esta compra!");
  }
}

function mouseDragged() {
  if (selecionado && gameState === "compra") {
    selecionado.x = mouseX;
    selecionado.y = mouseY;
  }
}

function mouseReleased() {
  if (selecionado && !selecionado.pego && gameState === "compra") {
    if (selecionado.overCarrinho(carrinho)) {
      selecionado.pego = true;
      coletados.push(selecionado.emoji);
      totalCompra += parseFloat(selecionado.preco);
    }
    selecionado = null;
  }
}

function keyPressed() {
  if (key === ' ' && gameState === "fim") {
    // Reinicia o jogo
    coletados = [];
    produtos = [];
    precos = [];
    totalCompra = 0;
    pagamentoRealizado = false;
    gameState = "compra";
    carrinhoMovendo = false;
    // Volta o carrinho para a posição original
    carrinho.x = 700;
    carrinho.y = height - 60;
    setup();
  }
}

class CartaoAnimado {
  constructor(metodo) {
    this.x = width/2 + 150;
    this.y = height/2;
    this.targetX = width/2;
    this.targetY = height/2;
    this.speed = 5;
    this.size = 30;
    this.finished = false;
    this.metodo = metodo;
    this.state = "approaching"; // approaching, processing, leaving
    this.processingTime = 100; // frames
    this.processingCounter = 0;
  }
  
  update() {
    if (this.state === "approaching") {
      this.x -= this.speed;
      if (this.x <= this.targetX) {
        this.state = "processing";
      }
    } 
    else if (this.state === "processing") {
      this.processingCounter++;
      if (this.processingCounter >= this.processingTime) {
        this.state = "leaving";
        saldoDisponivel = (parseFloat(saldoDisponivel) - totalCompra).toFixed(2);
      }
    }
    else if (this.state === "leaving") {
      this.x += this.speed;
      if (this.x > width) {
        this.finished = true;
      }
    }
  }
  
  show() {
    // Desenha a maquininha (simplificada)
    fill(100);
    rect(this.targetX - 60, this.targetY - 30, 120, 60, 10);
    fill(200);
    rect(this.targetX - 50, this.targetY - 20, 100, 40, 5);
    
    // Desenha o cartão
    fill(this.metodo === "Débito" ? 100 : 150, 200, 100);
    rect(this.x - 30, this.y - 20, 60, 40, 5);
    fill(255);
    textSize(12);
    text(this.metodo === "Débito" ? "DÉBITO" : "CRÉDITO", this.x, this.y);
    
    // Mostra mensagem durante o processamento
    if (this.state === "processing") {
      fill(0);
      textSize(14);
      text("Processando pagamento...", width/2, height/2 + 50);
    }
  }
}

class Produto {
  constructor(x, y, emoji, preco) {
    this.x = x;
    this.y = y;
    this.emoji = emoji;
    this.preco = preco;
    this.tamanho = 32;
    this.pego = false;
  }

  show() {
    if (!this.pego) {
      textSize(this.tamanho);
      text(this.emoji, this.x, this.y);
    }
  }
  
  showPreco() {
    textSize(12);
    fill(0);
    text(`R$ ${this.preco}`, this.x, this.y + 25);
  }

  isMouseOver() {
    return dist(mouseX, mouseY, this.x, this.y) < 20;
  }

  overCarrinho(carrinho) {
    return collideRectCircle(carrinho.x - 20, carrinho.y - 20, 40, 40, this.x, this.y, 20);
  }
}

class Carrinho {
  constructor() {
    this.x = 700;
    this.y = height - 60;
  }

  show() {
    textSize(40);
    text("🛒", this.x, this.y);
    
    if (coletados.length > 0 && !carrinhoMovendo) {
      textSize(16);
      text("→ Pagar", this.x + 40, this.y - 10);
    }
  }
}

class CaixaEletronico {
  constructor() {
    this.x = 800;
    this.y = 100;
  }

  show() {
    fill(180);
    rect(this.x, this.y, 80, 120, 10);
    fill(60);
    textSize(14);
    text("CAIXA", this.x + 40, this.y + 30);
    text("AUTO-", this.x + 40, this.y + 50);
    text("MÁTICO", this.x + 40, this.y + 70);
    
    // Adiciona ícone de dinheiro e cartão ao caixa
    textSize(20);
    text("💳", this.x + 20, this.y + 90);
    text("💵", this.x + 60, this.y + 90);
  }
}